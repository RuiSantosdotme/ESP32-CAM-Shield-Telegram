This shield is designed to be stacked to the ESP32-CAM. For this reason, if you want to use our PCB, you need the same ESP32-CAM AI Thinker Board board. The shield is equipped with a BME280 sensor and a PIR motion sensor.
https://randomnerdtutorials.com/esp32-cam-shield-pcb-telegram/
[Complete Project Details](https://randomnerdtutorials.com/esp32-cam-shield-pcb-telegram/)            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。